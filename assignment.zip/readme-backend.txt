/********** BACKEND NODE.JS *******************************/

/* RUN */
node script.js //listening on port 9090 //web URL: http://localhost:9090/articles

/* TEST - MOCHA/CHAI */
npm test 

/* INDEX PAGE */
http://localhost:9090/articles

/* VIEW ARTICLE PAGE */
http://localhost:9090/articles/wiki