/********** FRONTEND REACT *******************************/

/* RUN */
node start //web URL: http://localhost:8080

/* TEST */
npm run mytest 

/* INDEX PAGE */
http://localhost:8080/

/* VIEW ARTICLE PAGE */
http://localhost:8080/wiki

/* EDIT ARTICLE PAGE */
http://localhost:8080/edit/wiki